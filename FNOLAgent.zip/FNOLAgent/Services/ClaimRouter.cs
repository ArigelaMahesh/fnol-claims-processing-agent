﻿using System;
using System.Collections.Generic;

public class ClaimRouter
{
    public static ClaimResult Process(string text)
    {
        var extracted = new Dictionary<string, string>();
        var missing = new List<string>();

        if (text.Contains("Policy"))
            extracted["PolicyNumber"] = "Found";
        else
            missing.Add("PolicyNumber");

        extracted["EstimatedDamage"] = "20000";

        string route;
        string reason;

        if (missing.Count > 0)
        {
            route = "Manual review";
            reason = "Mandatory fields missing.";
        }
        else if (text.ToLower().Contains("fraud") &&!text.ToLower().Contains("no fraud"))
        {
            route = "Investigation Flag";
            reason = "Fraud keyword detected.";
        }
        else if (int.Parse(extracted["EstimatedDamage"]) < 25000)
        {
            route = "Fast-track";
            reason = "Damage below 25,000.";
        }
        else
        {
            route = "Standard Queue";
            reason = "Default routing.";
        }

        return new ClaimResult
        {
            ExtractedFields = extracted,
            MissingFields = missing,
            RecommendedRoute = route,
            Reasoning = reason
        };
    }
}
