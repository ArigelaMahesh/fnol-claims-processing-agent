﻿using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using System.Text;

public class PdfExtractor
{
    public static string ExtractText(string path)
    {
        StringBuilder text = new StringBuilder();

        using (PdfReader reader = new PdfReader(path))
        using (PdfDocument pdf = new PdfDocument(reader))
        {
            for (int i = 1; i <= pdf.GetNumberOfPages(); i++)
            {
                text.Append(PdfTextExtractor.GetTextFromPage(pdf.GetPage(i)));
            }
        }

        return text.ToString();
    }
}
