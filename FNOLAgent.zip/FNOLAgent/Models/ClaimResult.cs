﻿using System.Collections.Generic;

public class ClaimResult
{
    public Dictionary<string, string> ExtractedFields { get; set; }
    public List<string> MissingFields { get; set; }
    public string RecommendedRoute { get; set; }
    public string Reasoning { get; set; }
}
    