﻿using System;
using System.IO;
using Newtonsoft.Json;

class Program
{
    static void Main()
    {
        string filePath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory,
            "sample-fnol.txt"
        );

        string text = File.ReadAllText(filePath);
        ClaimResult result = ClaimRouter.Process(text);

        string json = JsonConvert.SerializeObject(result, Formatting.Indented);

        Console.WriteLine(json);
        Console.ReadLine();
    }
}
